#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "etlap.h"
#include "debugmalloc.h"


//Sorminta kirajzolasa a fomenu szamara.
static void sorminta_fomenu()
{
    for(int i = 0; i<50; i++)
    {
        printf("/");
        if(i == 49)
        {
            printf("\n");
        }
    }
}

//Sorminta kirajzolasa az almenuk szamara.
static void sorminta_almenu()
{
    for(int i = 0; i<50; i++)
    {
        printf("%%");
        if(i == 49)
        {
            printf("\n");
        }
    }
}

//A fomenu. Innen hivodnak meg a kulonbozo almenuk.
//A program a felhasznalotol egy szamot ker be, ami meghivja a megfelelo almenut.
//A kilepes a "9" bevitelevel tortenik.
void menu_valaszto(bool *kilep)
{
    menu_kirajzol();
    int valasztas;
    scanf("%d", &valasztas);
    switch (valasztas)
    {
    case 1:
        etlapkezeles();
        break;
    case 2:
        printf("Foglaltsagi terkep\n");
        break;
    case 3:
        asztalkezeles();
        break;
    case 4:
        printf("Szamla nyomtatasa kepernyore\n");
        break;
    case 9:
        printf("Kilepes, adatok mentese\n");
        *kilep = true;
        break;
    default:
        printf("Nincs ilyen valasztasi opcio!\n\n");
        break;
    }
}

//A menu valasztasi opcioit kiirja. Ezt a fomenu hijva meg.
void menu_kirajzol()
{
    sorminta_fomenu();
    printf("/");
    printf("%50s","/\n");
    printf("/");
    printf("%27s%23s","ETTEREM","/\n");
    printf("/");
    printf("%50s","/\n");
    sorminta_fomenu();
    printf("/");
    printf("%30s%20s","1. Menurogzites","/\n");
    printf("/");
    printf("%33s%17s","2. Foglaltsagi terkep","/\n");
    printf("/");
    printf("%32s%18s","3. Asztalok kezelese","/\n");
    printf("/");
    printf("%38s%12s","4. Szamla nyomtatas kepernyore","/\n");
    printf("/");
    printf("%36s%14s","9. Kilepes, adatok mentese","/\n");
    sorminta_fomenu();
    printf("/");
    printf("%43s%7s","Add meg a kivalasztott opcio sorszamat!","/\n");
    sorminta_fomenu();
}

//Az etelek listajat kezelo almenu opcioit iratja ki.
void etterem_menu()
{
    printf("\n");
    sorminta_almenu();
    printf("%%");
    printf("%35s%15s","1. Etlap megtekintese","%\n");
    printf("%%");
    printf("%33s%17s","2. Etel felvetele","%\n");
    printf("%%");
    printf("%32s%18s","3. Etel levetele","%\n");
    printf("%%");
    printf("%35s%15s","9. Vissza a fomenube","%\n");
    sorminta_almenu();
}

//Az asztalok kezelesere szolgalo almenu opcioit iratja ki.
void etterem_asztalok()
{
    printf("\n");
    sorminta_almenu();
    printf("%%");
    printf("%32s%18s","1. Asztal lefoglal","%\n");
    printf("%%");
    printf("%38s%12s","2. Asztal fogyasztas hozzaad","%\n");
    printf("%%");
    printf("%37s%13s","3. Asztal eddigi fogyasztas","%\n");
    printf("%%");
    printf("%30s%20s","4. Asztal torol","%\n");
    printf("%%");
    printf("%33s%17s","9. Vissza a fomenube","%\n");
    sorminta_almenu();
}

//Egy dinamikusan foglalt karaktertombot ad vissza, ha meghivjuk a fuggvenyt.
//Ezt kulonbozo etel nevek beolvasasara szolgal, ezt tobb .c fajl is hasznalja.
char *szoveg_beolvas()
{
    char *szoveg;
    szoveg = (char *) malloc(1* sizeof(char));
    int i = 0;
    szoveg[0] = '\0';
    char felesleges;                                      //az elotte levo szoveg ne zavarjon be
    scanf("%c", &felesleges);
    char temp;
    while(scanf("%c", &temp) == 1 && temp != '\n')
    {
        char *uj = (char*) malloc (sizeof(char) * (i+2));     //zaro nullanak is legyen hely
        for(int j = 0; j < i; ++j)
        {
            uj[j] = szoveg[j];
        }
        free(szoveg);
        szoveg = uj;
        uj[i] = temp;
        uj[i+1] = '\0';
        ++i;
    }

    return szoveg;
}

//Egy felhasznalo altal megadott integer erteket ad vissza.
//A fuggveny a meghivas utan beker egy szamot a felhasznalotol, amit ezutan return-ol.
int ar_beolvas()
{
    int szam;
    scanf("%d", &szam);
    return szam;
}

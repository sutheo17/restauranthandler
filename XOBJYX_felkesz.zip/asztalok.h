#ifndef ASZTAL
#define ASZTAL

typedef struct Asztalok
{
    int x, y;
    char **etel;
    int *db;
    bool foglalt;
    struct Asztalok *kov;
} Asztalok;

Asztalok *asztal_eleje;

Asztalok *asztalok_inicializalas(int sor, int oszlop);
Asztalok *asztalok_koordinata(Asztalok *asztal, int sor, int oszlop);
void asztalok_kiirat(Asztalok *eleje);
void foglaltsagi_terkep(Asztalok *eleje, int sor, int oszlop);
void *asztalok_foglaltsag(Asztalok *asztal);
Asztalok *asztalok_keres(Asztalok *eleje, int sor, int oszlop);
void asztalok_felszabadit(Asztalok *eleje);
void asztalok_keszit(int sor, int oszlop);

#endif

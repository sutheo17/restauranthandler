#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "menu.h"
#include "etlap.h"
#include "asztalok.h"
#include "debugmalloc.h"



int main()
{
    printf("Add meg az asztalok szamat! Ebben az alakban: [sorok szama,oszlopok szama]!\n");
    int sor, oszlop;
    scanf("%d,%d", &sor, &oszlop);
    asztalok_keszit(sor, oszlop);
    bool kilep = false;
    do{
       menu_valaszto(&kilep);
    } while (kilep == false);
    etlap_felszabadit(eleje);
    asztalok_felszabadit(asztal_eleje);
    return 0;
}

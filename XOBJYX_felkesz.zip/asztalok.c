#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "asztalok.h"
#include "menu.h"
#include "debugmalloc.h"

/*A lancolt lista elejere mutato pointer a header fajlban van deklaralva, ezaltal
  a foprogram(main) is latja, tud vele muveleteket vegezni.
  Erre a pointerre innentol kezdve "asztalok pointere" -kent fogok hivatkozni (Etlap *asztal_eleje)
*/

/*Ez a fuggveny a felhasznalotol egy szamot ker be. A felhasznalo altal
megadott szam felel a megfelelo opcio kivalasztasaert.
*/
void asztalkezeles()
{
    int valasztas;

    bool kilepes = false;
    while(kilepes == false)
    {
        etterem_asztalok();
        scanf("%d", &valasztas);
        switch (valasztas)
        {
        case 1:
            printf("1");
            break;
        case 2:
            printf("2");
            break;
        case 3:
            printf("3");
            break;
        case 4:
            printf("4");
            break;
        case 9:
            kilepes = true;
            printf("\n");
            break;
        default:
            printf("Nincs ilyen valasztasi opcio!\n");
            break;
        }
    }

}

/*A foprogram hivja meg ezt a fuggvenyt, ez kesziti el az asztalok pointeret.
  A fuggveny paramterebe ket integer erteket var, az elso helyen a sorok szama,
  masodik helyen az oszlopok szamat kell megadni.
  A lancolt lista tenyleges inicializasa a *asztalok_inicializalas fuggveny vegzi,
  ezt hivja meg a fuggveny lefutasa soran.
*/
void asztalok_keszit(int sor, int oszlop)
{
    asztal_eleje = asztalok_inicializalas(sor, oszlop);
}
/*A fuggveny meghivasa az asztalok pointerevel ter vissza, benne mar az asztalok
  x,y koordinataval vannak ellatva, valamint ossze vannak fuzve egy lancolt listaban.
  Paramterkent az *asztalok_keszit fuggveny adja at a foprogramban megadott
  sor-,valamint oszlopszamot.
*/
Asztalok *asztalok_inicializalas(int sor, int oszlop)
{
    Asztalok *legelso = (Asztalok*) malloc (sizeof(Asztalok));
    legelso = asztalok_koordinata(legelso, 0, 0);
    Asztalok *mozgo = legelso;
    legelso->kov = mozgo;

    for(int i = 1; i <= sor; i++)
    {
        for(int j = 1; j <= oszlop; j++)
        {
            Asztalok *uj = (Asztalok*) malloc (sizeof(Asztalok));
            uj = asztalok_koordinata(uj, i, j);
            uj->foglalt = false;
            uj->kov = NULL;
            mozgo->kov = uj;
            mozgo = mozgo->kov;
        }
    }
    return legelso;
}

/*Egy olyan pointerrel ter vissza, aminek az x es y koordinataja a paramterkent
  adott sor- �s oszlopszam.
  Parameterkent meg kell adnunk egy dinamikusan foglalt Asztalok tipusu
  pointert, valamint ket integer erteket, amely a sor-, es oszlopszamot jelolik.

*/
Asztalok *asztalok_koordinata(Asztalok *asztal, int sor, int oszlop)
{
    asztal->x = sor;
    asztal->y = oszlop;
    return asztal;
}

/*Az asztalok x es y koordinatajat irja ki.
  Paramterketn a asztalok pointeret kell megadnunk.
  Ez inkabb csak tesztjellegu fuggveny.
*/
void asztalok_kiirat(Asztalok *eleje)
{
    Asztalok *kiir;
    for(kiir = eleje; kiir != NULL; kiir = kiir->kov)
    {
        printf("x: %d y: %d\n", kiir->x, kiir->y);
    }
}

/*A fuggveny egy adott asztal foglaltsagat valtoztatja meg (foglaltrol szabadra, es forditva)
  A fuggveny paramterekent az adott asztalra mutato pointert kell megadnunk.
*/
void *asztalok_foglaltsag(Asztalok *asztal)
{
    (asztal->foglalt == false) ? (asztal->foglalt = true) : (asztal->foglalt = false);
}

/*Egy adott x,y koordinataju asztal pointerevel ter vissza.
  Paramterkent az asztalok pointeret, valamint ket integer erteket kell megadnunk
  sor-, valamint az oszlopszamot. (x,y koordinata)
*/
Asztalok *asztalok_keres(Asztalok *eleje, int sor, int oszlop)
{
    Asztalok *kereso;
    for(kereso = eleje; kereso != NULL; kereso = kereso->kov)
    {
        if(kereso->x == sor && kereso->y == oszlop)
        {
            return kereso;
        }
    }
    return eleje;
}

/*Az asztalok foglaltsagi terkepet rajzolja ki.
  Parameterkent az asztalok pointeret kell megadnunk, valamint ket integer erteket.
  Azt, hogy hany soru es oszlopu az ettermunk.

*/
void foglaltsagi_terkep(Asztalok *eleje, int sor, int oszlop)
{
    for(int i = 1; i <= sor; i++)
    {
        for(int j = 1; j <= oszlop; j++)
        {
            Asztalok *keresett = asztalok_keres(eleje, i, j);
            if(keresett->foglalt == false)
            {
                printf("O ");
            }
            else
            {
                printf("X ");
            }
        }
        printf("\n");
    }
}

/*
    Az asztalok pointerenek (a dinamikusan foglalt lancolt lista) felszabaditasaert felel.
    Paramterkent az asztalok pointeret kell megadnunk.
*/
void asztalok_felszabadit(Asztalok *eleje)
{
    Asztalok *torol = eleje;
    while (torol != NULL)
    {
        Asztalok *kovetkezo = torol->kov;
        free(torol);
        torol = kovetkezo;
    }
}

#ifndef MENU
#define MENU
#include <stdbool.h>



void menu_valaszto();
void menu_kirajzol();
void etterem_menu();
char *szoveg_beolvas();
int ar_beolvas();

#endif

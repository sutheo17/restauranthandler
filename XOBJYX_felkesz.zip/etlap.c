#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "etlap.h"
#include "menu.h"
#include "debugmalloc.h"

/*A lancolt lista elejere mutato pointer a header fajlban van deklaralva, ezaltal
  a foprogram(main) is latja, tud vele muveleteket vegezni.
  Erre a pointerre innentol kezdve "etlap" -kent fogok hivatkozni (Etlap *eleje)
*/

/*Ez a fuggveny a felhasznalotol egy szamot ker be. A felhasznalo altal
megadott szam felel a megfelelo opcio kivalasztasaert.
*/
void etlapkezeles()
{
    int valasztas;

    bool kilepes = false;
    while(kilepes == false)
    {
        etterem_menu();
        scanf("%d", &valasztas);
        switch (valasztas)
        {
        case 1:
            etlap_kiirat(eleje);
            break;
        case 2:
            eleje = etel_felvetel(eleje);
            break;
        case 3:
            eleje = etel_levetel(eleje);
            break;
        case 9:
            kilepes = true;
            printf("\n");
            break;
        default:
            printf("Nincs ilyen valasztasi opcio!\n");
            break;
        }
    }

}

/*A fuggveny az etlappal ter vissza.
  A felhasznalonak megkell adnia az etlapot paramterkent.
  A szoveg, valamint egy adag etel beolvasasahoz masik ket fuggveny hivodik meg.
  Majd meghivodik az *etel_felvetel fuggveny, amely a tenyleges etelfelfuzest teszi.

*/
Etlap *etel_felvetel(Etlap *eleje)
{
    char *etel;
    printf("Add meg az etel nevet, az enter a szoveg veget jelzi!\n");
    etel = szoveg_beolvas();
    int ar;
    printf("Add meg az etel adagarat!\n");
    ar = ar_beolvas();
    eleje = etlap_bovit(eleje, etel, ar);
    return eleje;
}

/*A fuggveny az etlappal ter vissza, de a paramterbe megadott
  etelt, valamint arat felveszi kovetkezo elemkent.
  Parameterkent az etlap kell, egy dinamikusan foglalt karaktertomb,
  valamint egy integer kell.
*/
Etlap *etlap_bovit(Etlap *eleje, char *etel, int ar)
{
    Etlap *uj = (Etlap*) malloc (sizeof(Etlap));
    int i;
    for(i= 0; etel[i] != '\0' ; i++)
    {
        uj->nev[i] = etel[i];
    }
    uj->nev[i] = '\0';
    uj->ar = ar;
    uj->kov = NULL;

    if (eleje == NULL)
    {
        eleje = uj;
        return eleje;
    }
    else
    {
        Etlap *mozgo = eleje;
        while (mozgo->kov != NULL)
        {
            mozgo = mozgo->kov;
        }
        mozgo->kov = uj;
        return eleje;
    }
}

/*Az etel levetelert felelos fuggveny.
  Parameterkent az etlapot kell megadnunk. A fuggveny beker
  a felhasznalotol egy sorszamot(integer) aminek a tenyleges
  lancolt lisarol valo torles az *etlap_torol fuggvennyel tortenik.

*/
Etlap *etel_levetel(Etlap *eleje)
{
    if(etel_db(eleje) == 0)
    {
        printf("Jelenleg nincs etel az etlapon!\n");
        return eleje;
    }
    printf("Adja meg a levenni kivant etel sorszamat!\n");
    int sorszam;
    scanf("%d", &sorszam);
    if(sorszam > etel_db(eleje))
    {
        printf("Tul nagy sorszamot adtal meg!\n");
        return eleje;
    }
    eleje = etlap_torol(eleje, sorszam);
}

/*Az etlap valahanyadik elemet torli ez a fuggveny meghivas utan.
  Meg kell adnunk az etlapot, valamint a levenni kivant etel sorszmat.
*/
Etlap *etlap_torol(Etlap *eleje, int sorszam)
{
    if(sorszam == 1)
    {
        Etlap *kovetkezo;
        kovetkezo = eleje->kov;
        free(eleje);
        return kovetkezo;
    }
    else
    {
        int i = 1;
        Etlap *elozo = NULL;
        Etlap *mozgo = eleje;
        while (i != sorszam)
        {
            elozo = mozgo;
            mozgo = mozgo->kov;
            i++;
        }
        elozo->kov = mozgo->kov;
        free(mozgo);
        return eleje;
    }
}

/*Az etlap darabszamaval ter vissza.
  Parameterkent az etlapot kell megadnunk.
*/
int etel_db(Etlap *eleje)
{
    Etlap *p;
    int db = 0;
    for(p = eleje; p != NULL; p = p->kov)
    {
        db++;
    }
    return db;
}

/* Kiiratja az etlapra felvett eteleket meghivasa utan
   Parameterkent meg kell adnunk az etlapot.
*/
void etlap_kiirat(Etlap *eleje)
{
    if(etel_db(eleje) == 0)
    {
        printf("\nJelenleg egyetlen egy etel sincs az etlapon.\n");
    }
    else
    {
        Etlap *kiir;
        int sorszam = 1;
        for(kiir = eleje; kiir != NULL; kiir = kiir->kov)
        {
            printf("%d %s - %d Ft\n", sorszam, kiir->nev, kiir->ar);
            sorszam++;
        }
        printf("Osszesen %d db etel van az etlapon.\n", etel_db(eleje));
    }
}

/*
    Az etlap (a dinamikusan foglalt lancolt listat) felszabaditasaert felel.
    Paramterkent az etlapot kell megadnunk.
*/
void etlap_felszabadit(Etlap *lista)
{
    Etlap *torol = lista;
    while (torol != NULL)
    {
        Etlap *kovetkezo = torol->kov;
        free(torol);
        torol = kovetkezo;
    }
}

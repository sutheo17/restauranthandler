#ifndef ETLAP
#define ETLAP

typedef struct Etlap{
    char nev[101];
    int ar;
    struct Etlap *kov;
} Etlap;

Etlap *eleje;

Etlap *etlap_bovit(Etlap *eleje, char *etel, int ar);
Etlap *etlap_torol(Etlap *eleje, int sorszam);
Etlap *etel_felvetel(Etlap *eleje);
Etlap *etel_levetel(Etlap *eleje);
void etlap_kiirat(Etlap *eleje);
void etlap_felszabadit(Etlap *lista);

#endif
